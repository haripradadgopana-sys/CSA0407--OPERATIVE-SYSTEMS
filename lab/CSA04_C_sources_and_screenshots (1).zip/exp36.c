#include <stdio.h>

int main()
{
    int used[50] = {0}, i, n, start, end, blk[20], prev;
    char name[20];

    used[4] = used[7] = used[12] = used[15] = used[18] = 1;      /* already occupied */
    printf("Enter the file name: ");
    scanf("%s", name);
    printf("Enter the number of blocks: ");
    scanf("%d", &n);
    printf("Enter the block numbers (free blocks only): ");
    for (i = 0; i < n; i++) {
        scanf("%d", &blk[i]);
        if (used[blk[i]]) { printf("Block %d is already allocated. Enter another: ", blk[i]); i--; continue; }
        used[blk[i]] = 1;
    }
    start = blk[0];
    end = blk[n - 1];
    printf("\nDirectory entry\nFile\tStart\tEnd\n%s\t%d\t%d\n", name, start, end);
    printf("\nLinked blocks of %s:\n", name);
    for (i = 0; i < n; i++) {
        prev = blk[i];
        if (i < n - 1) printf("Block %d -> points to block %d\n", prev, blk[i + 1]);
        else           printf("Block %d -> points to -1 (end of file)\n", prev);
    }
    return 0;
}
