#include <stdio.h>

int main()
{
    int n, f, pages[50], frames[10], i, j, k = 0, faults = 0, hit;
    printf("Enter the number of pages: ");
    scanf("%d", &n);
    printf("Enter the reference string: ");
    for (i = 0; i < n; i++) scanf("%d", &pages[i]);
    printf("Enter the number of frames: ");
    scanf("%d", &f);
    for (i = 0; i < f; i++) frames[i] = -1;

    printf("\nPage\tFrames\n");
    for (i = 0; i < n; i++) {
        hit = 0;
        for (j = 0; j < f; j++) if (frames[j] == pages[i]) hit = 1;
        if (!hit) {
            frames[k] = pages[i];            /* replace the oldest page */
            k = (k + 1) % f;
            faults++;
        }
        printf("%d\t", pages[i]);
        for (j = 0; j < f; j++) { if (frames[j] == -1) printf("- "); else printf("%d ", frames[j]); }
        printf("%s\n", hit ? "(hit)" : "(fault)");
    }
    printf("\nTotal Page Faults = %d\n", faults);
    return 0;
}
