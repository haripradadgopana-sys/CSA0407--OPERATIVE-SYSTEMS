#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define N 5
sem_t room, fork_sem[N];

void *philosopher(void *arg)
{
    int id = *(int *)arg;
    printf("Philosopher %d is thinking\n", id);
    usleep(50000 * (id + 1));
    sem_wait(&room);                    /* at most N-1 at the table: no deadlock */
    sem_wait(&fork_sem[id]);
    sem_wait(&fork_sem[(id + 1) % N]);
    printf("Philosopher %d is eating (forks %d and %d)\n", id, id, (id + 1) % N);
    usleep(100000);
    sem_post(&fork_sem[(id + 1) % N]);
    sem_post(&fork_sem[id]);
    sem_post(&room);
    printf("Philosopher %d finished eating and is thinking again\n", id);
    return NULL;
}

int main()
{
    pthread_t t[N];
    int id[N];
    sem_init(&room, 0, N - 1);
    for (int i = 0; i < N; i++) sem_init(&fork_sem[i], 0, 1);
    for (int i = 0; i < N; i++) { id[i] = i; pthread_create(&t[i], NULL, philosopher, &id[i]); }
    for (int i = 0; i < N; i++) pthread_join(t[i], NULL);
    printf("All philosophers have finished dining.\n");
    return 0;
}
