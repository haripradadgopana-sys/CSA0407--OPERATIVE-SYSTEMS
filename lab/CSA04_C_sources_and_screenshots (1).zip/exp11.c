#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

void *worker(void *arg)
{
    int id = *(int *)arg;
    for (int i = 1; i <= 3; i++) {
        printf("Thread %d : iteration %d\n", id, i);
        usleep(100000 * id);
    }
    printf("Thread %d : finished\n", id);
    return NULL;
}

int main()
{
    pthread_t t[3];
    int id[3] = {1, 2, 3};

    printf("Main thread: creating 3 threads\n");
    for (int i = 0; i < 3; i++)
        pthread_create(&t[i], NULL, worker, &id[i]);
    for (int i = 0; i < 3; i++)
        pthread_join(t[i], NULL);
    printf("Main thread: all threads completed\n");
    return 0;
}
