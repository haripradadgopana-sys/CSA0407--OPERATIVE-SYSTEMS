#include <stdio.h>
#include <stdlib.h>

struct record { int no; char name[20]; };

int main()
{
    FILE *fp = fopen("seq.dat", "wb");
    struct record r;
    int n, i, k;

    printf("Enter number of records to store: ");
    scanf("%d", &n);
    for (i = 1; i <= n; i++) {                    /* stored one after another */
        r.no = i;
        printf("Enter data for record %d: ", i);
        scanf("%s", r.name);
        fwrite(&r, sizeof(r), 1, fp);
    }
    fclose(fp);

    printf("\nEnter the record number to access: ");
    scanf("%d", &k);
    fp = fopen("seq.dat", "rb");
    printf("Sequential access (all previous records must be read first):\n");
    for (i = 1; i <= k; i++) {
        fread(&r, sizeof(r), 1, fp);
        printf("  reading record %d -> %s\n", r.no, r.name);
    }
    printf("Record %d accessed after reading %d record(s).\n", k, k);
    fclose(fp);
    return 0;
}
