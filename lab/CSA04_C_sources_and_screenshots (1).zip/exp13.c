#include <stdio.h>
#include <string.h>

#define MAXN 20
int nb, np, block[MAXN], proc[MAXN];

void allocate(const char *name, int strategy)
{
    int b[MAXN], alloc[MAXN], i, j, idx;
    memcpy(b, block, sizeof(int) * nb);
    for (i = 0; i < np; i++) alloc[i] = -1;
    for (i = 0; i < np; i++) {
        idx = -1;
        for (j = 0; j < nb; j++) {
            if (b[j] < proc[i]) continue;
            if (strategy == 0) { idx = j; break; }                      /* first fit */
            if (strategy == 1 && (idx == -1 || b[j] < b[idx])) idx = j; /* best fit  */
            if (strategy == 2 && (idx == -1 || b[j] > b[idx])) idx = j; /* worst fit */
        }
        if (idx != -1) { alloc[i] = idx; b[idx] -= proc[i]; }
    }
    printf("\n--- %s ---\nProcess\tSize\tBlock\n", name);
    for (i = 0; i < np; i++) {
        printf("P%d\t%d\t", i + 1, proc[i]);
        if (alloc[i] != -1) printf("%d\n", alloc[i] + 1);
        else printf("Not Allocated\n");
    }
}

int main()
{
    int i;
    printf("Enter number of memory blocks: ");
    scanf("%d", &nb);
    printf("Enter the size of each block: ");
    for (i = 0; i < nb; i++) scanf("%d", &block[i]);
    printf("Enter number of processes: ");
    scanf("%d", &np);
    printf("Enter the size of each process: ");
    for (i = 0; i < np; i++) scanf("%d", &proc[i]);
    allocate("FIRST FIT", 0);
    allocate("BEST FIT", 1);
    allocate("WORST FIT", 2);
    return 0;
}
