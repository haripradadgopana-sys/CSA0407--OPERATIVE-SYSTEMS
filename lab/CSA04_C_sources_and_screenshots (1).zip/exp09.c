#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

int main()
{
    int shmid = shmget(IPC_PRIVATE, 1024, IPC_CREAT | 0666);
    if (shmid < 0) { perror("shmget"); exit(1); }
    printf("Shared memory segment created, id = %d\n", shmid);

    if (fork() == 0) {                         /* child: reader */
        sleep(1);
        char *ptr = (char *)shmat(shmid, NULL, 0);
        printf("CHILD  : Data read from shared memory -> \"%s\"\n", ptr);
        shmdt(ptr);
        exit(0);
    } else {                                   /* parent: writer */
        char *ptr = (char *)shmat(shmid, NULL, 0);
        strcpy(ptr, "Hello from the parent process via shared memory!");
        printf("PARENT : Data written to shared memory -> \"%s\"\n", ptr);
        wait(NULL);
        shmdt(ptr);
        shmctl(shmid, IPC_RMID, NULL);
        printf("PARENT : Shared memory segment removed.\n");
    }
    return 0;
}
