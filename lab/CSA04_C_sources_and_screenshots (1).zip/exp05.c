#include <stdio.h>

int main()
{
    int n, i, j, pos, temp, total = 0;
    int bt[20], pr[20], p[20], wt[20], tat[20];
    float avg_wt, avg_tat;

    printf("Enter the total number of processes: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        p[i] = i + 1;
        printf("Enter burst time and priority of P%d: ", i + 1);
        scanf("%d %d", &bt[i], &pr[i]);
    }
    /* higher number = higher priority; pick highest first */
    for (i = 0; i < n; i++) {
        pos = i;
        for (j = i + 1; j < n; j++)
            if (pr[j] > pr[pos]) pos = j;
        temp = pr[i]; pr[i] = pr[pos]; pr[pos] = temp;
        temp = bt[i]; bt[i] = bt[pos]; bt[pos] = temp;
        temp = p[i];  p[i]  = p[pos];  p[pos]  = temp;
    }
    wt[0] = 0;
    for (i = 1; i < n; i++) {
        wt[i] = wt[i - 1] + bt[i - 1];
        total += wt[i];
    }
    avg_wt = (float)total / n;
    total = 0;
    printf("\nProcess\tPriority\tBurst\tWaiting\tTurnaround\n");
    for (i = 0; i < n; i++) {
        tat[i] = bt[i] + wt[i];
        total += tat[i];
        printf("P%d\t%d\t\t%d\t%d\t%d\n", p[i], pr[i], bt[i], wt[i], tat[i]);
    }
    avg_tat = (float)total / n;
    printf("\nAverage Waiting Time    = %.2f", avg_wt);
    printf("\nAverage Turnaround Time = %.2f\n", avg_tat);
    return 0;
}
