#include <stdio.h>
#include <stdlib.h>

int main()
{
    FILE *fp;
    char line[100];

    fp = fopen("student.txt", "w");                      /* create / write */
    fprintf(fp, "Operating Systems\nFile management operations\n");
    fclose(fp);
    printf("1. File 'student.txt' created and written.\n");

    fp = fopen("student.txt", "a");                      /* append */
    fprintf(fp, "Appended line: SIMATS Engineering\n");
    fclose(fp);
    printf("2. A new line appended to the file.\n");

    printf("3. Contents of the file:\n");                /* read */
    fp = fopen("student.txt", "r");
    while (fgets(line, sizeof(line), fp)) printf("   %s", line);
    fclose(fp);

    if (rename("student.txt", "records.txt") == 0)       /* rename */
        printf("4. File renamed to 'records.txt'.\n");

    if (remove("records.txt") == 0)                      /* delete */
        printf("5. File 'records.txt' deleted.\n");

    fp = fopen("records.txt", "r");
    if (fp == NULL) printf("6. Confirmed: 'records.txt' no longer exists.\n");
    return 0;
}
