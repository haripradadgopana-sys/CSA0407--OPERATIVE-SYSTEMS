#include <stdio.h>

int main()
{
    int f[50] = {0}, index[50], i, n, ib, more = 1, blk, ok;
    char name[20];

    while (more) {
        printf("Enter the file name: ");
        scanf("%s", name);
        printf("Enter the index block: ");
        scanf("%d", &ib);
        if (f[ib]) { printf("Block %d is already allocated\n\n", ib); goto ask; }
        f[ib] = 1;
        printf("Enter the number of blocks needed by %s: ", name);
        scanf("%d", &n);
        printf("Enter the block numbers: ");
        ok = 1;
        for (i = 0; i < n; i++) {
            scanf("%d", &blk);
            if (f[blk]) { printf("Block %d already allocated\n", blk); ok = 0; }
            else { index[i] = blk; f[blk] = 1; }
        }
        if (ok) {
            printf("\nFile %s allocated. Index block %d contains:\n", name, ib);
            for (i = 0; i < n; i++)
                printf("  index[%d] -> block %d\n", i, index[i]);
            printf("\n");
        }
    ask:
        printf("Do you want to enter more files (1 = Yes / 0 = No): ");
        scanf("%d", &more);
    }
    return 0;
}
