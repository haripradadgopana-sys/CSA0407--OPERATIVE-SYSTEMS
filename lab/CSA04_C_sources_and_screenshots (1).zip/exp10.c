#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/wait.h>

struct msgbuf_t { long mtype; char mtext[100]; };

int main()
{
    int qid = msgget(IPC_PRIVATE, IPC_CREAT | 0666);
    if (qid < 0) { perror("msgget"); exit(1); }
    printf("Message queue created, id = %d\n", qid);

    if (fork() == 0) {                          /* child: receiver */
        struct msgbuf_t m;
        for (int i = 0; i < 3; i++) {
            msgrcv(qid, &m, sizeof(m.mtext), 1, 0);
            printf("RECEIVER: got message -> \"%s\"\n", m.mtext);
        }
        exit(0);
    } else {                                    /* parent: sender */
        struct msgbuf_t m;
        const char *msgs[3] = {"Operating Systems", "Message Queue IPC", "Hello from sender"};
        m.mtype = 1;
        for (int i = 0; i < 3; i++) {
            strcpy(m.mtext, msgs[i]);
            msgsnd(qid, &m, strlen(m.mtext) + 1, 0);
            printf("SENDER  : sent message -> \"%s\"\n", m.mtext);
        }
        wait(NULL);
        msgctl(qid, IPC_RMID, NULL);
        printf("Message queue removed.\n");
    }
    return 0;
}
