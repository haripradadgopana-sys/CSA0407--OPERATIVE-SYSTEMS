#include <stdio.h>
#include <stdlib.h>

struct emp { int id; char name[20]; float salary; };

int main()
{
    FILE *fp = fopen("employee.dat", "wb+");
    struct emp e;
    int ch, rec;
    if (fp == NULL) { printf("Cannot open file\n"); exit(1); }
    while (1) {
        printf("\n1. Add record  2. Display record  3. Update record  4. Exit\nEnter your choice: ");
        scanf("%d", &ch);
        if (ch == 1) {
            printf("Enter record number (1,2,3..): ");
            scanf("%d", &rec);
            printf("Enter Employee ID, Name, Salary: ");
            scanf("%d %s %f", &e.id, e.name, &e.salary);
            fseek(fp, (long)(rec - 1) * sizeof(struct emp), SEEK_SET);
            fwrite(&e, sizeof(e), 1, fp);
            printf("Record %d stored.\n", rec);
        } else if (ch == 2) {
            printf("Enter record number to display: ");
            scanf("%d", &rec);
            fseek(fp, (long)(rec - 1) * sizeof(struct emp), SEEK_SET);
            if (fread(&e, sizeof(e), 1, fp) == 1)
                printf("ID: %d  Name: %s  Salary: %.2f\n", e.id, e.name, e.salary);
            else
                printf("Record not found\n");
        } else if (ch == 3) {
            printf("Enter record number to update: ");
            scanf("%d", &rec);
            printf("Enter new Employee ID, Name, Salary: ");
            scanf("%d %s %f", &e.id, e.name, &e.salary);
            fseek(fp, (long)(rec - 1) * sizeof(struct emp), SEEK_SET);
            fwrite(&e, sizeof(e), 1, fp);
            printf("Record %d updated.\n", rec);
        } else break;
        fflush(fp);
    }
    fclose(fp);
    return 0;
}
