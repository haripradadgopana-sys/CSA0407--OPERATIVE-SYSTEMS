#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main()
{
    pid_t pid;
    printf("Parent started. PID = %d, PPID = %d\n", getpid(), getppid());
    pid = fork();
    if (pid < 0) {
        perror("fork failed");
        exit(1);
    } else if (pid == 0) {
        printf("CHILD  : Process ID = %d, Parent Process ID = %d\n", getpid(), getppid());
    } else {
        wait(NULL);
        printf("PARENT : Process ID = %d, Child Process ID = %d\n", getpid(), pid);
    }
    return 0;
}
