#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

/* Classical problem: Sleeping Barber (3 waiting chairs, 6 customers) */
#define CHAIRS 3
#define CUSTOMERS 6
sem_t customers, barber;
pthread_mutex_t seats = PTHREAD_MUTEX_INITIALIZER;
int waiting = 0, served = 0, left = 0;

void *barber_fn(void *arg)
{
    while (1) {
        sem_wait(&customers);
        pthread_mutex_lock(&seats);
        waiting--;
        pthread_mutex_unlock(&seats);
        sem_post(&barber);
        printf("Barber is cutting hair...\n");
        usleep(300000);
        served++;
        if (served + left == CUSTOMERS) break;
    }
    return NULL;
}

void *customer_fn(void *arg)
{
    int id = *(int *)arg;
    pthread_mutex_lock(&seats);
    if (waiting < CHAIRS) {
        waiting++;
        printf("Customer %d sits in the waiting room (waiting = %d)\n", id, waiting);
        pthread_mutex_unlock(&seats);
        sem_post(&customers);
        sem_wait(&barber);
        printf("Customer %d is getting a haircut\n", id);
    } else {
        left++;
        printf("Customer %d finds no free chair and leaves\n", id);
        pthread_mutex_unlock(&seats);
    }
    return NULL;
}

int main()
{
    pthread_t b, c[CUSTOMERS];
    int id[CUSTOMERS];
    sem_init(&customers, 0, 0);
    sem_init(&barber, 0, 0);
    pthread_create(&b, NULL, barber_fn, NULL);
    for (int i = 0; i < CUSTOMERS; i++) {
        id[i] = i + 1;
        pthread_create(&c[i], NULL, customer_fn, &id[i]);
        usleep(100000);
    }
    for (int i = 0; i < CUSTOMERS; i++) pthread_join(c[i], NULL);
    pthread_join(b, NULL);
    printf("\nCustomers served = %d, customers who left = %d\n", served, left);
    return 0;
}
