#include <stdio.h>
#include <pthread.h>

int counter = 0;
pthread_mutex_t lock;

void *increment(void *arg)
{
    int id = *(int *)arg;
    for (int i = 0; i < 100000; i++) {
        pthread_mutex_lock(&lock);
        counter++;                      /* critical section */
        pthread_mutex_unlock(&lock);
    }
    printf("Thread %d finished its work\n", id);
    return NULL;
}

int main()
{
    pthread_t t1, t2;
    int a = 1, b = 2;
    pthread_mutex_init(&lock, NULL);
    pthread_create(&t1, NULL, increment, &a);
    pthread_create(&t2, NULL, increment, &b);
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
    printf("Expected counter value = 200000\n");
    printf("Final counter value    = %d\n", counter);
    pthread_mutex_destroy(&lock);
    return 0;
}
