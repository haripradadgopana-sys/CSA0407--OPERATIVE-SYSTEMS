#include <stdio.h>

int n, m, alloc[10][10], max[10][10], need[10][10], avail[10];

int is_safe(int show)
{
    int work[10], fin[10] = {0}, seq[10], cnt = 0, i, j, found;
    for (j = 0; j < m; j++) work[j] = avail[j];
    while (cnt < n) {
        found = 0;
        for (i = 0; i < n; i++) {
            if (fin[i]) continue;
            for (j = 0; j < m && need[i][j] <= work[j]; j++);
            if (j == m) {
                for (j = 0; j < m; j++) work[j] += alloc[i][j];
                fin[i] = 1; seq[cnt++] = i; found = 1;
            }
        }
        if (!found) { printf("System is NOT in a safe state (deadlock possible)\n"); return 0; }
    }
    if (show) {
        printf("System is in a SAFE state.\nSafe sequence: ");
        for (i = 0; i < n; i++) printf("P%d%s", seq[i], i < n - 1 ? " -> " : "\n");
    }
    return 1;
}

int main()
{
    int i, j, req[10], p;
    printf("Enter number of processes: ");  scanf("%d", &n);
    printf("Enter number of resource types: "); scanf("%d", &m);
    printf("Enter Allocation matrix:\n");
    for (i = 0; i < n; i++) for (j = 0; j < m; j++) scanf("%d", &alloc[i][j]);
    printf("Enter Max matrix:\n");
    for (i = 0; i < n; i++) for (j = 0; j < m; j++) scanf("%d", &max[i][j]);
    printf("Enter Available resources: ");
    for (j = 0; j < m; j++) scanf("%d", &avail[j]);
    for (i = 0; i < n; i++) for (j = 0; j < m; j++) need[i][j] = max[i][j] - alloc[i][j];

    printf("\nNeed matrix:\n");
    for (i = 0; i < n; i++) { printf("P%d: ", i); for (j = 0; j < m; j++) printf("%d ", need[i][j]); printf("\n"); }
    printf("\n");
    is_safe(1);

    printf("\nEnter requesting process number: "); scanf("%d", &p);
    printf("Enter request vector: ");
    for (j = 0; j < m; j++) scanf("%d", &req[j]);
    for (j = 0; j < m; j++)
        if (req[j] > need[p][j] || req[j] > avail[j]) { printf("Request cannot be granted now (exceeds need/available)\n"); return 0; }
    for (j = 0; j < m; j++) { avail[j] -= req[j]; alloc[p][j] += req[j]; need[p][j] -= req[j]; }
    if (is_safe(0)) printf("Request can be GRANTED immediately.\n");
    else printf("Request must WAIT (granting would be unsafe).\n");
    return 0;
}
