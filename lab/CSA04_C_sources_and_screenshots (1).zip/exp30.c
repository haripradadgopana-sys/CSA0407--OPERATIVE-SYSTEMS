#include <stdio.h>
#include <pthread.h>

pthread_t t1, t2;

void *task(void *arg)
{
    printf("Thread %s is running (id = %lu)\n", (char *)arg, (unsigned long)pthread_self());
    pthread_exit((void *)"exit status from thread");          /* (iv) exit */
}

int main()
{
    void *status;
    pthread_create(&t1, NULL, task, "T1");                     /* (i) create */
    pthread_create(&t2, NULL, task, "T2");

    if (pthread_equal(t1, t2))                                 /* (iii) equal */
        printf("t1 and t2 are the same thread\n");
    else
        printf("t1 and t2 are different threads\n");
    if (pthread_equal(t1, t1))
        printf("t1 is equal to itself\n");

    pthread_join(t1, &status);                                 /* (ii) join */
    printf("T1 joined, returned: %s\n", (char *)status);
    pthread_join(t2, &status);
    printf("T2 joined, returned: %s\n", (char *)status);
    return 0;
}
