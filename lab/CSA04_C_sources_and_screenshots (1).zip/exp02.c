#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>

int main()
{
    int src, dst, n;
    char buf[512], sname[100], dname[100];

    printf("Enter the source file name      : ");
    scanf("%s", sname);
    printf("Enter the destination file name : ");
    scanf("%s", dname);

    src = open(sname, O_RDONLY);
    if (src < 0) { perror("open source"); exit(1); }
    dst = open(dname, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (dst < 0) { perror("open destination"); exit(1); }

    while ((n = read(src, buf, sizeof(buf))) > 0)
        write(dst, buf, n);

    close(src);
    close(dst);
    printf("Contents copied from %s to %s successfully.\n", sname, dname);
    return 0;
}
