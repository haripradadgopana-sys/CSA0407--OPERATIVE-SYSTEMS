#include <stdio.h>

int main()
{
    int n, i, tq, time = 0, done = 0, progress;
    int at[20], bt[20], rt[20], ct[20], wt[20], tat[20];
    float awt = 0, atat = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        printf("Enter arrival time and burst time of P%d: ", i + 1);
        scanf("%d %d", &at[i], &bt[i]);
        rt[i] = bt[i];
    }
    printf("Enter the time quantum: ");
    scanf("%d", &tq);

    while (done < n) {
        progress = 0;
        for (i = 0; i < n; i++) {
            if (at[i] <= time && rt[i] > 0) {
                int run = rt[i] < tq ? rt[i] : tq;
                time += run;
                rt[i] -= run;
                progress = 1;
                if (rt[i] == 0) { ct[i] = time; done++; }
            }
        }
        if (!progress) time++;
    }
    printf("\nProcess\tAT\tBT\tCT\tTAT\tWT\n");
    for (i = 0; i < n; i++) {
        tat[i] = ct[i] - at[i];
        wt[i] = tat[i] - bt[i];
        awt += wt[i]; atat += tat[i];
        printf("P%d\t%d\t%d\t%d\t%d\t%d\n", i + 1, at[i], bt[i], ct[i], tat[i], wt[i]);
    }
    printf("\nAverage Waiting Time    = %.2f", awt / n);
    printf("\nAverage Turnaround Time = %.2f\n", atat / n);
    return 0;
}
