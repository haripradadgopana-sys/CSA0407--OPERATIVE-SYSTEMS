#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>

int main()
{
    struct dirent **list;
    int n, i;
    n = scandir(".", &list, NULL, alphasort);
    if (n < 0) { perror("scandir"); exit(1); }
    for (i = 0; i < n; i++) {
        if (list[i]->d_name[0] != '.')          /* like plain ls: hide dot files */
            printf("%s  ", list[i]->d_name);
        free(list[i]);
    }
    printf("\n");
    free(list);
    return 0;
}
