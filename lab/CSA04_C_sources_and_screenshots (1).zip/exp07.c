#include <stdio.h>

int main()
{
    int n, i, k, time = 0, done = 0, sel;
    int at[20], bt[20], ct[20], wt[20], tat[20], fin[20] = {0};
    float awt = 0, atat = 0;

    printf("Enter the number of processes: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        printf("Enter arrival time and burst time of P%d: ", i + 1);
        scanf("%d %d", &at[i], &bt[i]);
    }
    while (done < n) {
        sel = -1;
        for (k = 0; k < n; k++)
            if (!fin[k] && at[k] <= time && (sel == -1 || bt[k] < bt[sel]))
                sel = k;
        if (sel == -1) { time++; continue; }
        time += bt[sel];            /* run to completion (non-preemptive) */
        ct[sel] = time;
        fin[sel] = 1;
        done++;
    }
    printf("\nProcess\tAT\tBT\tCT\tWT\tTAT\n");
    for (i = 0; i < n; i++) {
        tat[i] = ct[i] - at[i];
        wt[i] = tat[i] - bt[i];
        awt += wt[i]; atat += tat[i];
        printf("P%d\t%d\t%d\t%d\t%d\t%d\n", i + 1, at[i], bt[i], ct[i], wt[i], tat[i]);
    }
    printf("\nAverage Waiting Time    = %.2f", awt / n);
    printf("\nAverage Turnaround Time = %.2f\n", atat / n);
    return 0;
}
