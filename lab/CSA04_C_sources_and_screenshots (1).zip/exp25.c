#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <sys/stat.h>

int main()
{
    int fd, flags;
    char buf[50];
    struct stat st;
    struct dirent *de;
    DIR *dp;

    fd = open("demo.txt", O_RDWR | O_CREAT | O_TRUNC, 0644);
    write(fd, "Operating Systems Lab: I/O system calls", 39);

    flags = fcntl(fd, F_GETFL);                         /* fcntl */
    printf("fcntl  : file status flags = %d (O_RDWR = %d)\n", flags & O_ACCMODE, O_RDWR);

    lseek(fd, 10, SEEK_SET);                            /* seek */
    memset(buf, 0, sizeof(buf));
    read(fd, buf, 10);
    printf("lseek  : 10 bytes read from offset 10 -> \"%s\"\n", buf);
    close(fd);

    stat("demo.txt", &st);                              /* stat */
    printf("stat   : size = %ld bytes, inode = %ld, links = %ld, mode = %o\n",
           (long)st.st_size, (long)st.st_ino, (long)st.st_nlink, st.st_mode & 0777);

    dp = opendir(".");                                  /* opendir / readdir */
    printf("readdir: files in the current directory:\n");
    while ((de = readdir(dp)) != NULL)
        if (strstr(de->d_name, ".txt") || strstr(de->d_name, "notes"))
            printf("         %s\n", de->d_name);
    closedir(dp);
    return 0;
}
