#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

void show(const char *file)
{
    struct stat st;
    stat(file, &st);
    mode_t m = st.st_mode;
    char s[10] = "---------";
    if (m & S_IRUSR) s[0] = 'r';  if (m & S_IWUSR) s[1] = 'w';  if (m & S_IXUSR) s[2] = 'x';
    if (m & S_IRGRP) s[3] = 'r';  if (m & S_IWGRP) s[4] = 'w';  if (m & S_IXGRP) s[5] = 'x';
    if (m & S_IROTH) s[6] = 'r';  if (m & S_IWOTH) s[7] = 'w';  if (m & S_IXOTH) s[8] = 'x';
    printf("\nPermissions of %s : -%s  (octal %o)\n", file, s, m & 0777);
    printf("  Owner (user) : %c%c%c\n", s[0], s[1], s[2]);
    printf("  Group        : %c%c%c\n", s[3], s[4], s[5]);
    printf("  Others       : %c%c%c\n", s[6], s[7], s[8]);
}

int main()
{
    int fd = open("perm.txt", O_CREAT | O_WRONLY, 0644);
    write(fd, "permission demo\n", 16);
    close(fd);
    printf("Types of users: u = owner, g = group, o = others, a = all\n");
    printf("Permissions   : r = read (4), w = write (2), x = execute (1)\n");

    show("perm.txt");                         /* created with 0644 */
    chmod("perm.txt", 0754);                  /* chmod u=rwx,g=rx,o=r */
    printf("\nAfter chmod 754 perm.txt:");
    show("perm.txt");
    chmod("perm.txt", 0600);                  /* chmod 600 */
    printf("\nAfter chmod 600 perm.txt:");
    show("perm.txt");
    return 0;
}
