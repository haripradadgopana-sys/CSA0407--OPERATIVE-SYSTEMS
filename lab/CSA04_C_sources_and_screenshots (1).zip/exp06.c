#include <stdio.h>

int main()
{
    int n, i, time = 0, done = 0, best;
    int at[20], bt[20], rt[20], pr[20], ct[20], wt[20], tat[20];
    float awt = 0, atat = 0;

    printf("Enter number of processes: ");
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        printf("Enter arrival time, burst time, priority of P%d: ", i + 1);
        scanf("%d %d %d", &at[i], &bt[i], &pr[i]);
        rt[i] = bt[i];
    }
    /* lower number = higher priority; preempt every time unit */
    while (done < n) {
        best = -1;
        for (i = 0; i < n; i++)
            if (at[i] <= time && rt[i] > 0 && (best == -1 || pr[i] < pr[best]))
                best = i;
        if (best == -1) { time++; continue; }
        rt[best]--;
        time++;
        if (rt[best] == 0) { ct[best] = time; done++; }
    }
    printf("\nProcess\tAT\tBT\tPR\tCT\tWT\tTAT\n");
    for (i = 0; i < n; i++) {
        tat[i] = ct[i] - at[i];
        wt[i] = tat[i] - bt[i];
        awt += wt[i]; atat += tat[i];
        printf("P%d\t%d\t%d\t%d\t%d\t%d\t%d\n", i + 1, at[i], bt[i], pr[i], ct[i], wt[i], tat[i]);
    }
    printf("\nAverage Waiting Time    = %.2f", awt / n);
    printf("\nAverage Turnaround Time = %.2f\n", atat / n);
    return 0;
}
