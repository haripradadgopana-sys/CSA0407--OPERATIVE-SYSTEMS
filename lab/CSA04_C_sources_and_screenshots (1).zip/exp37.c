#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, q[50], head, total = 0, cur;
    printf("Enter the number of requests: ");
    scanf("%d", &n);
    printf("Enter the request queue: ");
    for (i = 0; i < n; i++) scanf("%d", &q[i]);
    printf("Enter the initial head position: ");
    scanf("%d", &head);

    cur = head;
    printf("\nHead movement sequence: %d", cur);
    for (i = 0; i < n; i++) {
        total += abs(q[i] - cur);
        cur = q[i];
        printf(" -> %d", cur);
    }
    printf("\n\nTotal head movement = %d cylinders\n", total);
    return 0;
}
