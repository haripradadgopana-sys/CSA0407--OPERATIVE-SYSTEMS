#include <stdio.h>

int main()
{
    int nb, np, b[20], p[20], alloc[20], i, j, idx;
    printf("Enter number of memory blocks: ");
    scanf("%d", &nb);
    printf("Enter the size of each block: ");
    for (i = 0; i < nb; i++) scanf("%d", &b[i]);
    printf("Enter number of processes: ");
    scanf("%d", &np);
    printf("Enter the size of each process: ");
    for (i = 0; i < np; i++) { scanf("%d", &p[i]); alloc[i] = -1; }

    for (i = 0; i < np; i++) {
        idx = -1;
        for (j = 0; j < nb; j++) {
            if (b[j] < p[i]) continue;
            if (2 == 0) { idx = j; break; }                        /* WORST FIT */
            if (2 == 1 && (idx == -1 || b[j] < b[idx])) idx = j;
            if (2 == 2 && (idx == -1 || b[j] > b[idx])) idx = j;
        }
        if (idx != -1) { alloc[i] = idx; b[idx] -= p[i]; }
    }
    printf("\n--- WORST FIT ---\nProcess No.\tProcess Size\tBlock No.\n");
    for (i = 0; i < np; i++) {
        printf("%d\t\t%d\t\t", i + 1, p[i]);
        if (alloc[i] != -1) printf("%d\n", alloc[i] + 1);
        else printf("Not Allocated\n");
    }
    return 0;
}
