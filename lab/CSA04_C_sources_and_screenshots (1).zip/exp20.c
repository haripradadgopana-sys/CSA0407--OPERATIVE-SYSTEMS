#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

sem_t wrt;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
int data = 0, readcount = 0;

void *writer(void *arg)
{
    int id = *(int *)arg;
    sem_wait(&wrt);
    data++;
    printf("Writer %d wrote data = %d\n", id, data);
    usleep(100000);
    sem_post(&wrt);
    return NULL;
}

void *reader(void *arg)
{
    int id = *(int *)arg;
    pthread_mutex_lock(&mutex);
    if (++readcount == 1) sem_wait(&wrt);
    pthread_mutex_unlock(&mutex);

    printf("Reader %d read data = %d\n", id, data);
    usleep(100000);

    pthread_mutex_lock(&mutex);
    if (--readcount == 0) sem_post(&wrt);
    pthread_mutex_unlock(&mutex);
    return NULL;
}

int main()
{
    pthread_t r[3], w[2];
    int id[3] = {1, 2, 3};
    sem_init(&wrt, 0, 1);
    pthread_create(&w[0], NULL, writer, &id[0]);
    usleep(20000);
    pthread_create(&r[0], NULL, reader, &id[0]);
    pthread_create(&r[1], NULL, reader, &id[1]);
    usleep(20000);
    pthread_create(&w[1], NULL, writer, &id[1]);
    pthread_create(&r[2], NULL, reader, &id[2]);
    for (int i = 0; i < 2; i++) pthread_join(w[i], NULL);
    for (int i = 0; i < 3; i++) pthread_join(r[i], NULL);
    return 0;
}
