#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, i, j, t, q[50], head, disk, total = 0, cur, idx;
    printf("Enter the number of requests: ");
    scanf("%d", &n);
    printf("Enter the request queue: ");
    for (i = 0; i < n; i++) scanf("%d", &q[i]);
    printf("Enter the initial head position: ");
    scanf("%d", &head);
    printf("Enter the disk size (number of cylinders): ");
    scanf("%d", &disk);

    for (i = 0; i < n - 1; i++)
        for (j = 0; j < n - i - 1; j++)
            if (q[j] > q[j + 1]) { t = q[j]; q[j] = q[j + 1]; q[j + 1] = t; }
    for (idx = 0; idx < n && q[idx] < head; idx++);

    cur = head;
    printf("\nHead movement sequence: %d", cur);
    for (i = idx; i < n; i++) { total += abs(q[i] - cur); cur = q[i]; printf(" -> %d", cur); }
    total += (disk - 1) - cur; cur = disk - 1; printf(" -> %d", cur);       /* go to last cylinder */
    total += disk - 1; cur = 0; printf(" -> %d", cur);                       /* jump back to 0 */
    for (i = 0; i < idx; i++) { total += abs(q[i] - cur); cur = q[i]; printf(" -> %d", cur); }
    printf("\n\nTotal head movement = %d cylinders\n", total);
    return 0;
}
