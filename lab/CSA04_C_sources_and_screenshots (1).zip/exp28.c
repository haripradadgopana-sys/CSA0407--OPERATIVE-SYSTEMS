#include <stdio.h>
#include <string.h>

int main()
{
    FILE *fp;
    char fn[50], pat[50], line[200];
    int ln = 0, found = 0;

    printf("Enter the file name : ");
    scanf("%s", fn);
    printf("Enter the pattern   : ");
    scanf("%s", pat);
    fp = fopen(fn, "r");
    if (fp == NULL) { printf("Cannot open %s\n", fn); return 1; }
    printf("\nLines in %s containing \"%s\":\n", fn, pat);
    while (fgets(line, sizeof(line), fp)) {
        ln++;
        if (strstr(line, pat)) { printf("%d: %s", ln, line); found++; }
    }
    printf("\n%d matching line(s) found.\n", found);
    fclose(fp);
    return 0;
}
